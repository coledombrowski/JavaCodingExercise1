/* Java Coding Exercise 1
   Fall 2023
   Student: Cole Dombrowski
   Date: 9/8/2023
 */
 
package dombrowski.jce1.students;

public class StudentDriver
{
    public static void main(String[] args)
    {
		// Declare a Student object
        Student sandy;
		
		// JCE1: Instantiate the Student object by calling
		// the construtor with four parameters. This used to
		// be the full-init constructor, but with the addtion
		// of the new instance variable it is not full-init
		// any more
        sandy = new Student("10001", "Sandy", 'F', 3.9f);        

		// Display student info without setting values to new
		// instance variable
        
        displayStudent(sandy);

        // JCE1: Set values to new instance variable
        sandy.setAge(9);
        sandy.age = 9;
		// Display student info after value has been set
        displayStudent(sandy);
    }

    public static void displayStudent(Student s)
    {
        System.out.println("********************************");
        System.out.print("Generated in StudentDriver Class");
        System.out.print("\nStudent Name: " + s.getName());
        System.out.print("\nUNT ID: " + s.getUNTID());
        System.out.print("\nGender: '" + s.getGender() + "'");
        System.out.println("\nGPA: " + s.getGPA());

        // JCE1: Additional statement to display new variable
        System.out.println("\nAge:" + s.getAge());

        System.out.println("********************************\n");
    }

}
