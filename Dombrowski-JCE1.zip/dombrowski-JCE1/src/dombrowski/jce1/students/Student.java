/* Java Coding Exercise 1
   Fall 2023
   Student: Cole Dombrowski
   Date: 9/8/2023
 */
 
package dombrowski.jce1.students;

public class Student
{
    //***** Static Variable *****//
    static int studentCount;

    //***** Instance Variables *****//
    private String untId;
    private String name;
    private char gender;
    private float gpa;

	// JCE1
    // Declare new instance variable
    public int age; // I set this back to public so I can combile and save ;)

    // Setter for age with validation
    public void setAge(int a)
    {
        if (a <= 11)
        {
            age = -1;
        }
        else
        {
            age = a;   
        }
    }

    // Getter for age
    public int getAge()
    {
        return age;
    }
   
    // Used-to-be full-initialization constructor
	// This constructor was the full-init contructor, taking 
	// four parameters, each for a particular instance variable.
	// With the addition of the new instance variable, it isn't
	// full-init any more
    public Student(String i, String n, char g, float gpa)
    {
        // Initializes instance variables of the new object 
        untId = i;
        name = n;
        gender = g;
        this.gpa = gpa;

        // Add 1 to the static variable for object count
        studentCount++;
    }

    // Default contructor
    public Student()
    {
        // No instance variables are initialized
        // Still should add 1 to the count of objects since
        // this DOES create a new object
        studentCount++;
    }

    // Partial initialization constructor
    public Student(String i, String n)
    {
        // Initializes only two of the four instance variables.
        untId = i;
        name = n;

        // Add 1 to the static variable for object count
        studentCount++;
    }

    // ***** Setters and Getters *****//
    // For UNT ID //
    public void setUNTID(String id)
    {
        untId = id;
    }

    public String getUNTID()
    {
        return untId;
    }

    // For Name //
    public void setName(String name)
    {
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    // For Gender //
    public void setGender(char gender)
    {
        this.gender = gender;
    }

    public char getGender()
    {
        return gender;
    }

    // For Age //
    public void setGPA(float gpa)
    {
        this.gpa = gpa;
    }

    public float getGPA()
    {
        return gpa;
    }

    // ***** Static Methods *****//
    // This is for illustration only. Since the object count is incremented in
    // in the contructors, there are rare, if at any, cases this would be really
    // needed to run.
    static void addToCount()
    {
        studentCount++;
    }

    static int readStudentCount()
    {
        return studentCount;
    }

    // ***** Instance Method *****//
    public void describeSelf()
    {
        String msg = "================================\n";
        msg += "Generated in Student Class\n";
        msg += untId + "\t" + name + "\t" + gpa + "\n";
        msg += "================================";

        System.out.println(msg);
    }

}
